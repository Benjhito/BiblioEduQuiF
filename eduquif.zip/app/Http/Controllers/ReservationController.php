<?php

namespace App\Http\Controllers;

use App\Models\Reservation;
use App\Exports\ReservationsExport;
use Illuminate\Http\Request;
use App\Exports\ReservationsListPdf;
use Maatwebsite\Excel\Facades\Excel;

class ReservationController extends Controller
{
    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Reservation $reservation)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Reservation $reservation)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Reservation $reservation)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Reservation $reservation)
    {
        //
    }

    public function list()
    {
        $title = 'Listado de Reservas';
        $line = str_repeat('-', 95);

        $pdf = new ReservationsListPdf();
        $pdf->AliasNbPages();
        $pdf->SetMargins(12, 20);
        $pdf->AddPage('P', 'A4');
        $pdf->SetTitle($title);
        $pdf->SetAuthor('Benjamin Emanuel Tito');
        $pdf->SetCreator('Benjamin Emanuel Tito');
        $pdf->SetSubject($title);

        $reservationTotal = 0;

        $search = session()->get('search-6.2');

        $reservations = Reservation::lastName($search)
            ->orWhere->memberCode($search)
            ->orWhere->bookCode($search)
            ->orWhere->isbn($search)
            ->orWhere->title($search)
            ->orWhere->author($search)
            ->dateRange(session()->get('iniDate-6.2'), session()->get('finDate-6.2'))
            ->orderBy(session()->get('sort-6.2'), session()->get('direction-6.2'))
            ->get();

        foreach ($reservations as $reservation) {

            $row = $reservation->res_date->format('d/m/y') . '  ' .
                str_pad(utf8_decode(substr($reservation->member->code . '-' . $reservation->member->fullName(), 0, 27)), 28, ' ') .
                str_pad(utf8_decode(substr($reservation->book->title . '-' . $reservation->book->author, 0, 42)), 45, ' ') .
                str_pad($reservation->status, 12, ' ');

            $pdf->Cell(0, 4, $row, 0, 1);

            $reservationTotal += 1;
        }

        $pdf->Cell(0, 3, $line, 0, 1);
        $pdf->SetFont('Courier', 'B', 9);
        $pdf->Cell(0, 5, 'Cantidad de Registros:' . str_pad((string)$reservationTotal, 6, ' ', STR_PAD_LEFT), 0, 1);

        return response($pdf->output('S'), 200)
            ->header('Content-Type', 'application/pdf')
            ->header('Content-disposition', 'filename=ListadoReservas(' . now()->format('d-m-Y') . ').pdf');
    }

    public function export(ReservationsExport $reservationsExport)
    {
        return Excel::download($reservationsExport, 'Reservas(' . now()->format('d-m-Y') . ').xlsx');
    }
}
