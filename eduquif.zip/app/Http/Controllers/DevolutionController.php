<?php

namespace App\Http\Controllers;

use App\Models\Devolution;
use App\Exports\DevolutionsExport;
use Illuminate\Http\Request;
use App\Exports\DevolutionsListPdf;
use Maatwebsite\Excel\Facades\Excel;

class DevolutionController extends Controller
{
    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Devolution $devolution)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Devolution $devolution)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Devolution $devolution)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Devolution $devolution)
    {
        //
    }

    public function list()
    {
        $title = 'Listado de Devoluciones';
        $line = str_repeat('-', 95);

        $pdf = new DevolutionsListPdf();
        $pdf->AliasNbPages();
        $pdf->SetMargins(12, 20);
        $pdf->AddPage('P', 'A4');
        $pdf->SetTitle($title);
        $pdf->SetAuthor('Benjamin Emanuel Tito');
        $pdf->SetCreator('Benjamin Emanuel Tito');
        $pdf->SetSubject($title);

        $devolutionTotal = 0;

        $search = session()->get('search-7.2');

        $devolutions = Devolution::lastName($search)
            ->orWhere->memberCode($search)
            ->orWhere->bookCode($search)
            ->orWhere->isbn($search)
            ->orWhere->title($search)
            ->orWhere->author($search)
            ->dateRange(session()->get('iniDate-7.2'), session()->get('finDate-7.2'))
            ->orderBy(session()->get('sort-7.2'), session()->get('direction-7.2'))
            ->get();

        foreach ($devolutions as $devolution) {

            $row = $devolution->dev_date->format('d/m/y') . '  ' .
                str_pad(utf8_decode(substr($devolution->member->code . '-' . $devolution->member->fullName(), 0, 27)), 28, ' ') .
                str_pad(utf8_decode(substr($devolution->book->title . '-' . $devolution->book->author, 0, 42)), 45, ' ') .
                str_pad($devolution->status, 12, ' ');

            $pdf->Cell(0, 4, $row, 0, 1);

            $devolutionTotal += 1;
        }

        $pdf->Cell(0, 3, $line, 0, 1);
        $pdf->SetFont('Courier', 'B', 9);
        $pdf->Cell(0, 5, 'Cantidad de Registros:' . str_pad((string)$devolutionTotal, 6, ' ', STR_PAD_LEFT), 0, 1);

        return response($pdf->output('S'), 200)
            ->header('Content-Type', 'application/pdf')
            ->header('Content-disposition', 'filename=ListadoDevoluciones(' . now()->format('d-m-Y') . ').pdf');
    }

    public function export(DevolutionsExport $devolutionsExport)
    {
        return Excel::download($devolutionsExport, 'Devoluciones(' . now()->format('d-m-Y') . ').xlsx');
    }
}
