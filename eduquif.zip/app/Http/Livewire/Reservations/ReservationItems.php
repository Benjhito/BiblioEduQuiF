<?php

namespace App\Http\Livewire\Reservations;

use Livewire\Component;

class ReservationItems extends Component
{
    public function render()
    {
        return view('livewire.reservations.reservation-items');
    }
}
