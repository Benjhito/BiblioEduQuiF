<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Reservation extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var string[]
     */
    protected $fillable = [
        'res_date',
        'member_id',
        'book_id',
        'status',
        'notes',
    ];

    protected $casts = [
        'res_date' => 'date:Y-m-d',
    ];

    public function scopeMemberId($query, $memberId)
    {
        if ($memberId)
            return $query->where('member_id', $memberId);
    }

    public function scopeBookId($query, $bookId)
    {
        if ($bookId)
            return $query->where('book_id', $bookId);
    }

    public function scopeLastName($query, $lastName)
    {
        if ($lastName)
            return $query->whereHas('member', function ($q) use ($lastName) {
                    $q->where('last_name', 'ilike', "%{$lastName}%");
                });
    }

    public function scopeMemberCode($query, $code)
    {
        if ($code)
            return $query->whereHas('member', function ($q) use ($code) {
                    $q->where('code', 'ilike', "%{$code}%");
                });
    }

    public function scopeBookCode($query, $code)
    {
        if ($code)
            return $query->whereHas('book', function ($q) use ($code) {
                    $q->where('code', 'ilike', "%{$code}%");
                });
    }

    public function scopeIsbn($query, $isbn)
    {
        if ($isbn)
            return $query->whereHas('book', function ($q) use ($isbn) {
                    $q->where('isbn', 'ilike', "%{$isbn}%");
                });
    }

    public function scopeTitle($query, $title)
    {
        if ($title)
            return $query->whereHas('book', function ($q) use ($title) {
                    $q->where('title', 'ilike', "%{$title}%");
                });
    }
/*
    public function scopeSubtitle($query, $subtitle)
    {
        if ($subtitle)
            return $query->whereHas('book', function ($q) use ($subtitle) {
                    $q->where('subtitle', 'ilike', "%{$subtitle}%");
                });
    }

    public function scopeDescrip($query, $descrip)
    {
        if ($descrip)
            return $query->whereHas('book', function ($q) use ($descrip) {
                    $q->where('descrip', 'ilike', "%{$descrip}%");
                });
    }
*/
    public function scopeAuthor($query, $author)
    {
        if ($author)
            return $query->whereHas('book', function ($q) use ($author) {
                    $q->where('author', 'ilike', "%{$author}%");
                });
    }

    public function scopeDateRange($query, $iniDate, $finDate)
    {
        if ($iniDate or $finDate)
            return $query->when($iniDate, function ($q) use ($iniDate) {
                    $q->whereDate('res_date', '>=', $iniDate);
                })
                ->when($finDate, function ($q) use ($finDate) {
                    $q->whereDate('res_date', '<=', $finDate);
                });
    }

    /**
     * The relationships that should always be loaded.
     *
     * @var array
     */
    protected $with = [
        'member',
        'book',
    ];

    public function member()
    {
        return $this->belongsTo(Member::class);
    }

    public function book()
    {
        return $this->belongsTo(Book::class);
    }
}
