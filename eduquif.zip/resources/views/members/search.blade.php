@extends("layouts.app")

@section("content")
    @livewire('member-search')
@endsection
