@extends("layouts.app")

@section("content")
    @include("books.form")
@endsection
