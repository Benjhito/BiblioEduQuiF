<tr>
  <td colspan="20">
    <div class="container-fluid mt-3">
      <div class="d-flex alert alert-danger shadow-sm align-items-center justify-content-center" role="alert">
        <img width="25px" height="25px" src="{{ asset('images/icons8-general-warning-sign-48.png') }}" alt="Warning">
        <span class="text-danger ml-3 mb-0">No hay resultados.</span>
      </div>
    </div>
  </td>
</tr>
