@extends("layouts.app")

@section("content")
    @include("collections.form")
@endsection
