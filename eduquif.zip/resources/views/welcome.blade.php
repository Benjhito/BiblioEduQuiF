@extends("layouts.app")

@section("content")
    <style type="text/css">
        body {
            background:url({{ asset('images/background.jpg') }}) repeat 0 0;
        }
    </style>

    <center><h1>Bienvenido al Sistema de Gestión Administrativa!</h1></center>
@endsection
