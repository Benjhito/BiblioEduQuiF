@extends("layouts.app")

@section("content")
    @include("categories.form")
@endsection
