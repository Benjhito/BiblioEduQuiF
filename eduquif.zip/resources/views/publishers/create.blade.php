@extends("layouts.app")

@section("content")
    @include("publishers.form")
@endsection
