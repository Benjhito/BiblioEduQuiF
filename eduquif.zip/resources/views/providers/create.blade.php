@extends("layouts.app")

@section("content")
    @include("providers.form")
@endsection
